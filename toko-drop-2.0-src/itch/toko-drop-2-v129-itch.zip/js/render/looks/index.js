// index.js — how each species looks, one module each (docs/SIM_CONTRACT.md).
import globbo from './globbo.js?v=129';
import yela from './yela.js?v=129';
import spittor from './spittor.js?v=129';
import fanner from './fanner.js?v=129';
import orange from './orange.js?v=129';
import weeva from './weeva.js?v=129';
import sludge from './sludge.js?v=129';
import bambu from './bambu.js?v=129';
import splitta from './splitta.js?v=129';
import redd from './redd.js?v=129';
import reddmini from './reddmini.js?v=129';
import purp from './purp.js?v=129';
import purpmini from './purpmini.js?v=129';
import pyra from './pyra.js?v=129';
import botfly from './botfly.js?v=129';
import toro from './toro.js?v=129';
import bulwark from './bulwark.js?v=129';
import warden from './warden.js?v=129';
import draper from './draper.js?v=129';
import siren from './siren.js?v=129';
import cloaker from './cloaker.js?v=129';
import magna from './magna.js?v=129';
import shepherd from './shepherd.js?v=129';
import ribbon from './ribbon.js?v=129';
import slug from './slug.js?v=129';
import omega from './omega.js?v=129';
import prism from './prism.js?v=129';
import hoppa from './hoppa.js?v=129';
import worma from './worma.js?v=129';
import bubbla from './bubbla.js?v=129';
import glowa from './glowa.js?v=129';
import curbking from './curbking.js?v=129';
import maw from './maw.js?v=129';
import blister from './blister.js?v=129';
import kettle from './kettle.js?v=129';
import pike from './pike.js?v=129';
import berg from './berg.js?v=129';
import angler from './angler.js?v=129';

export const LOOKS = {
  globbo, yela, spittor, fanner, orange, weeva, sludge, bambu, splitta, redd, reddmini, purp, purpmini, pyra, botfly, toro, bulwark, warden, draper, siren, cloaker, magna, shepherd, ribbon, slug, omega, prism, hoppa, worma, bubbla, glowa, curbking, maw, blister, kettle, pike, berg, angler,
};
