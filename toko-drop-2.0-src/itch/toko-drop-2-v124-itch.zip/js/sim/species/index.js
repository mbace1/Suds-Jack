// index.js — every species' behaviour, one module each (docs/SIM_CONTRACT.md).
import globbo from './globbo.js?v=124';
import yela from './yela.js?v=124';
import spittor from './spittor.js?v=124';
import fanner from './fanner.js?v=124';
import orange from './orange.js?v=124';
import weeva from './weeva.js?v=124';
import sludge from './sludge.js?v=124';
import bambu from './bambu.js?v=124';
import splitta from './splitta.js?v=124';
import redd from './redd.js?v=124';
import reddmini from './reddmini.js?v=124';
import purp from './purp.js?v=124';
import purpmini from './purpmini.js?v=124';
import pyra from './pyra.js?v=124';
import botfly from './botfly.js?v=124';
import toro from './toro.js?v=124';
import bulwark from './bulwark.js?v=124';
import warden from './warden.js?v=124';
import draper from './draper.js?v=124';
import siren from './siren.js?v=124';
import cloaker from './cloaker.js?v=124';
import magna from './magna.js?v=124';
import shepherd from './shepherd.js?v=124';
import ribbon from './ribbon.js?v=124';
import slug from './slug.js?v=124';
import omega from './omega.js?v=124';
import prism from './prism.js?v=124';
import hoppa from './hoppa.js?v=124';
import worma from './worma.js?v=124';
import bubbla from './bubbla.js?v=124';
import steama from './steama.js?v=124';
import salma from './salma.js?v=124';
import skata from './skata.js?v=124';
import glowa from './glowa.js?v=124';
import mirra from './mirra.js?v=124';
import curbking from './curbking.js?v=124';
import maw from './maw.js?v=124';
import blister from './blister.js?v=124';
import kettle from './kettle.js?v=124';
import pike from './pike.js?v=124';
import berg from './berg.js?v=124';
import angler from './angler.js?v=124';

export const BEHAVIOUR = {
  globbo, yela, spittor, fanner, orange, weeva, sludge, bambu, splitta, redd, reddmini, purp, purpmini, pyra, botfly, toro, bulwark, warden, draper, siren, cloaker, magna, shepherd, ribbon, slug, omega, prism, hoppa, worma, bubbla, steama, salma, skata, glowa, mirra, curbking, maw, blister, kettle, pike, berg, angler,
};
