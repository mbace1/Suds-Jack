// species/index.js — every species' numbers, one file each (so a species
// port touches only its own file). TUNING.species is this object.
import globbo from './globbo.js?v=142';
import yela from './yela.js?v=142';
import spittor from './spittor.js?v=142';
import fanner from './fanner.js?v=142';
import orange from './orange.js?v=142';
import weeva from './weeva.js?v=142';
import sludge from './sludge.js?v=142';
import bambu from './bambu.js?v=142';
import splitta from './splitta.js?v=142';
import redd from './redd.js?v=142';
import reddmini from './reddmini.js?v=142';
import purp from './purp.js?v=142';
import purpmini from './purpmini.js?v=142';
import pyra from './pyra.js?v=142';
import botfly from './botfly.js?v=142';
import toro from './toro.js?v=142';
import bulwark from './bulwark.js?v=142';
import warden from './warden.js?v=142';
import draper from './draper.js?v=142';
import siren from './siren.js?v=142';
import cloaker from './cloaker.js?v=142';
import magna from './magna.js?v=142';
import shepherd from './shepherd.js?v=142';
import ribbon from './ribbon.js?v=142';
import slug from './slug.js?v=142';
import omega from './omega.js?v=142';
import prism from './prism.js?v=142';
import hoppa from './hoppa.js?v=142';
import worma from './worma.js?v=142';
import bubbla from './bubbla.js?v=142';
import steama from './steama.js?v=142';
import salma from './salma.js?v=142';
import skata from './skata.js?v=142';
import glowa from './glowa.js?v=142';
import mirra from './mirra.js?v=142';
import curbking from './curbking.js?v=142';
import maw from './maw.js?v=142';
import blister from './blister.js?v=142';
import kettle from './kettle.js?v=142';
import pike from './pike.js?v=142';
import berg from './berg.js?v=142';
import angler from './angler.js?v=142';

export const SPECIES = {
  globbo, yela, spittor, fanner, orange, weeva, sludge, bambu, splitta, redd, reddmini, purp, purpmini, pyra, botfly, toro, bulwark, warden, draper, siren, cloaker, magna, shepherd, ribbon, slug, omega, prism, hoppa, worma, bubbla, steama, salma, skata, glowa, mirra, curbking, maw, blister, kettle, pike, berg, angler,
};
